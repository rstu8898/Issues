function display()
{
				var mpt=parseInt(document.getElementById("marks1").value);
				var mtt=parseInt(document.getElementById("marks2").value);
				var assignment=parseInt(document.getElementById("marks3").value);
				var result=mpt+mtt+assignment;
				alert("Score is :"+result);
}
function display1()
{

	var data=window.document.emp.domain.value;
	if(data=="JEE")
	{
		window.document.emp.catval.options[0].text="Core Java";
		window.document.emp.catval.options[0].value="Core Java";
		
		window.document.emp.catval.options[1].text="Servlet-Jsp";
		window.document.emp.catval.options[1].value="Servlet-Jsp";
		
		window.document.emp.catval.options[2].text="Spring";
		window.document.emp.catval.options[2].value="Spring";
		
		
	}
	if(data==".NET")
	{
		window.document.emp.catval.options[0].text="C#";
		window.document.emp.catval.options[0].value="C#";
		
		window.document.emp.catval.options[1].text="ADO.NET";
		window.document.emp.catval.options[1].value="ADO.NET";
		
window.document.emp.catval.options[2].text="ASP.NET";
		window.document.emp.catval.options[2].value="ASP.NET";
	}



}