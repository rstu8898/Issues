$(document).ready(function() {
	employee.init();
});

var employee = new  Employee ();
function Employee () {
	var dataTableId = "companyTable";
	var popupId = "companyPopup";
	var SUCCESS_MSG_ID = "form-success-div";
	var ERROR_MSG_ID = "form-error-div";
	var bean = {};
	var dataTableObj = null;
	var currentAction = "";
	var totalRecords = 0;
	var divFlag = false;
	this.init = init;
	this.showPopup = showPopup;
	this.addRecord = addRecord;
	
	
	function init() {
		//resetModel ();	
		//loadDataTable ();
	//	setProfileData();
	}
	
	function showPopup (action, data) {
		resetModel ();
		currentAction = action;
		if (action == 'ADD') {
			showAddForm ();
			return;
		} else if (action == 'EDIT') {
			showEditForm (data);
			return;
		} else if (action == 'VIEW') {
			showViewForm (data);
		}
	}
	

	function addRecord () {
			var name=$("#firstName").val();
			if (!validateName(name)) {
				return false;
			}

		var objConfig = {}; 
		objConfig['type'] = 'POST';
		objConfig['url'] = "http://localhost:8081/employee/save";
		objConfig['data'] = JSON.stringify(bean);
		objConfig['dataType'] = 'json';
		objConfig['success'] = function (response) {
			if (response.status == 'SUCCESS') {
				utility.viewFormMessageAlert (SUCCESS_MSG_ID, response.message);
				if (dataTableObj != null) {
					dataTableObj.ajax.reload();
				}
			} else {
				utility.viewFormMessageAlert (ERROR_MSG_ID, response.message);
			}
		};
		objConfig['error'] = function (response) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, response.message);
		};
		
		ajax.callAjax (objConfig);
	}
	
	
	

	function showAddForm () {
		utility.showForm();
		$('.actionButton').hide();
		$('#addButton').hide();
		$('#cancelButton').show();
		$('#editButton').show();
		$("#withdrawDiv").hide();
	}
	
	function showViewForm (data) {
		utility.showForm();	
		$('.actionButton').hide();
		$('#cancelButton').show();
		$("#withdrawDiv").hide();
		bean = dataTable.allBeans[data];
		setFormBean ();
	}
	
	function showEditForm (data) {
		utility.showForm();
		$('.actionButton').hide();
		$('#cancelButton').show();
		$('#editButton').show();
		bean = dataTable.allBeans[data];
		setFormBean ();
	}
	
	function hidePopup () {
		$('#'+popupId).modal('hide');
	}
	
	
		
	function scrollToTop(){
		utility.scrollToTop();
	}
	
	function validateName (name) {
		if (!utility.isAlphaNumericSpace (name)) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, "Invalid Name : Name cannot be Empty");
			return false;
		}
		return true;
	}

	function validateAddress (address) {
		if (!utility.isAlphaNumericSpace (address)) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, "Invalid Address : Address cannot be Empty");
			return false;
		}
		return true;
	}
	
	function validatePlanType (planTypeId) {
		if (!utility.isAlphaNumeric (planTypeId)) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, "Invalid Plan Type : Please Select Plan Type");
			return false;
		}
		return true;
	}
	
	function validateCodePrefix (codePrefix) {
		if (!utility.isAlphaNumeric (codePrefix)) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, "Invalid Code Prefix : Code Prefix cannot be Empty");
			return false;
		}
		return true;
	}
	
	function validateCurrencySign (currencySign) {
		if (!utility.isAlphaNumeric (currencySign)) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, "Invalid Currency Sign : Currency Sign cannot be Empty");
			return false;
		}
		return true;
	}
	
	function validateCurrencyCode (currencyCode) {
		if (!utility.isAlphaNumeric (currencyCode)) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, "Invalid Currency Code : Currency Code cannot be Empty");
			return false;
		}
		return true;
	}
	
	function validateMinAmountToWithdraw (minAmountToWithdraw) {
		if(divFlag == true){
		if (!utility.isNumeric (minAmountToWithdraw)) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, "Invalid Withdraw Amount :  Withdraw Amount must be Numeric ");
			return false;
		}
		}
		return true;
	}
	
	function validateNoOfChilds (noOfChilds) {
		if (!utility.isNumeric (noOfChilds)) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, "Invalide Number : Number of Childs must be Numeric");
			return false;
		}
		return true;
	}
	
	function validatePayoutTax (payoutTax) {
		if (!utility.isNumeric (payoutTax)) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, "Invalide Payout Tax : Payout Tax must be Numeric");
			return false;
		}
		return true;
	}

}


