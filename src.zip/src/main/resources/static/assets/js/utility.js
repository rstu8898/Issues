																																																																																																																																																																																																	
$(document).ready(function() {
	utility.lodderHide ();
});

var countryStateCityUtility = new CountryStateCityUtility ();
function CountryStateCityUtility () {
	var bean = {};
	
	this.setBean = setBean;
	this.getBean = getBean;
	this.countryList = countryList;
	this.stateList = stateList;
	this.cityList = cityList;
	this.loadCitysState = loadCitysState;
	this.getCitysStateCountryByPincode = getCitysStateCountryByPincode;
	
	function setBean (b) {
		bean = b
	}
	
	function getBean () {
		return bean;
	}
	
	function countryList (eleId){
		var objectConfig = {}; 
		objectConfig['type'] = 'GET';
		objectConfig['url'] = serviceURL + "/masters/loadCountrys";
		objectConfig['data'] = {};
		objectConfig['dataType'] = 'json';
		
		objectConfig['success'] = function (response) {
			if (response.status == 'SUCCESS') {
				$.map(response.response, function( val, i ) {
					$('#'+eleId).append($('<option>', { 
					        value: i,
					        text : val 
					}));
				});
			} else {
				utility.viewErrorFooterAlert (response.message);
			}
		};
		objectConfig['error'] = function (response) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, response.message);
		};
		ajax.callAjax (objectConfig);
	}
	
	function loadCitysState (countryEleId, stateEleId, cityEleId) {
		
		var countryStateCitySearch = {};
		countryStateCitySearch['country'] = bean.country;
		countryStateCitySearch['state'] = bean.state;
		countryStateCitySearch['city'] = bean.city;
		
		var objectConfig = {}; 
		objectConfig['type'] = 'POST';
		objectConfig['url'] = serviceURL + "/masters/loadCitysState";
		objectConfig['data'] = JSON.stringify(countryStateCitySearch);
		objectConfig['dataType'] = 'json';
		
		objectConfig['success'] = function (response) {
			if (response.status == 'SUCCESS') {
				
				$('#'+stateEleId).empty();
				$('#'+stateEleId).append($('<option>', { value: "", text : "SELECT STATE" }));
				$.each(response.response.state, function( index, value ) {
					$('#'+stateEleId).append($('<option>', { value: value.key_s, text : value.stateName_s }));
				});
				
				$('#'+cityEleId).empty();
				$('#'+cityEleId).append($('<option>', { value: "", text : "SELECT CITY" }));
				$.each(response.response.city, function( index, value ) {
					$('#'+cityEleId).append($('<option>', { value: value.key_s, text : value.cityName_s }));
				});
			
				$("#"+countryEleId).val(countryStateCitySearch.country);
				$("#"+stateEleId).val(countryStateCitySearch.state);
				$("#"+cityEleId).val(countryStateCitySearch.city);
			} else {
				utility.viewErrorFooterAlert (response.message);
			}
		};
		objectConfig['error'] = function (response) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, response.message);
		};
		ajax.callAjax (objectConfig);
	}
	
    function getCitysStateCountryByPincode (pincodeBean) {
		
		var pincode = pincodeBean["pincode"];
		var countryEleId = pincodeBean["country"];
		var stateEleId = pincodeBean["state"];
		var cityEleId = pincodeBean["city"];
		
		var objectConfig = {}; 
		objectConfig['type'] = 'GET';
		objectConfig['url'] = serviceURL + "/master/getCitysStateCountryByPincode?pincode="+pincode;
		objectConfig['data'] = {};
		objectConfig['dataType'] = 'json';
		
		objectConfig['success'] = function (response) {
			if (response.status == 'SUCCESS') {
				$('#'+stateEleId).val(response.response.state);
				$('#'+cityEleId).val(response.response.city);
				$("#"+countryEleId).val(response.response.country);
			} else {
				utility.viewErrorFooterAlert (response.message);
			}
		};
		objectConfig['error'] = function (response) {
			utility.viewFormMessageAlert (ERROR_MSG_ID, response.message);
		};
		ajax.callAjax (objectConfig);
	}
	
	function cityList (stateEleId, cityEleId){
		var objectConfig = {}; 
		var state = utility.removeWhiteSpace ($("#"+stateEleId).val());
		objectConfig['type'] = 'GET';
		objectConfig['url'] = serviceURL + "/masters/loadCitys/"+state;
		objectConfig['data'] = {};
		objectConfig['dataType'] = 'json';
		
		objectConfig['success'] = function (response) {
			if (response.status == 'SUCCESS') {
				$('#'+cityEleId).empty();
				$('#'+cityEleId).append($('<option>', { value: "", text : "SELECT CITY" }));
				$.each(response.response, function( index, value ) {
					$('#'+cityEleId).append($('<option>', { value: value.key_s, text : value.cityName_s }));
				});
			} else {
				utility.viewErrorFooterAlert (response.message);
			}
		};
		objectConfig['error'] = function (response) {
			utility.viewErrorFooterAlert (response.message);
		};
		ajax.callAjax (objectConfig);
	}
	
	function stateList (countryEleId, stateEleId) {
		var objectConfig = {}; 
		var country = utility.removeWhiteSpace ($("#"+countryEleId).val());
		objectConfig['type'] = 'GET';
		objectConfig['url'] = serviceURL + "/masters/loadStates/"+country;
		objectConfig['data'] = {};
		objectConfig['dataType'] = 'json';
		
		objectConfig['success'] = function (response) {
			if (response.status == 'SUCCESS') {
				$('#'+stateEleId).empty();
				$('#'+stateEleId).append($('<option>', { value: "", text : "SELECT STATE" }));
				$.each(response.response, function( index, value ) {
					$('#'+stateEleId).append($('<option>', { value: value.key_s, text : value.stateName_s }));
				});
			} else {
				utility.viewErrorFooterAlert (response.message);
			}
		};
		objectConfig['error'] = function (response) {
			utility.viewErrorFooterAlert (response.message);
		};
		ajax.callAjax (objectConfig);
	}
}

var dataTable = new DataTable ();
function DataTable () {
	var allBeans = {}; 
	this.loadDataTable  = loadDataTable;
	this.loadTableWithoutPagination = loadTableWithoutPagination;
	
	function loadDataTable (objects) {
		
		var buttons = [];
		buttons.push ({extend: 'csv', className: 'csvButton'});
		if (objects.externalButtons != undefined) {
			var buttons = $.merge(buttons, objects.externalButtons);
		}
		if (objects.externalButtons1 != undefined) {
			var buttons = $.merge(buttons, objects.externalButtons1);
		}
		
		var referrer = window.location.pathname;
		if (objects.ajax.url.indexOf("?") >= 0) {
			objects.ajax.url = objects.ajax.url + "referrer="+referrer+"&isAjax="+true;
		} else {
			objects.ajax.url = objects.ajax.url + "?referrer="+referrer+"&isAjax="+true;
		}
		
		var dataTableObject = $('#'+objects.tableID).DataTable({
	        serverSide	: true,
	        autoWidth: false,
			dom: '<"datatable-header"fBl><"datatable-scroll-wrap"t><"datatable-footer"ip>',
	        pageLength  : 10,
	        paging		: true,
	        searching	: { "regex": true },
	        language: {
				search: '<span>Filter:</span> _INPUT_',
				lengthMenu: '<span>Show:</span> _MENU_',
				paginate: { 'first': 'First', 'last': 'Last', 'next': '&rarr;', 'previous': '&larr;' }
			},
	        columns		: objects.columns,
	  	    order 		: objects.order,
	        buttons		:{ dom: {
								button: { className: 'btn btn-secondary' }
						 },
						 buttons: buttons 
						 }, 
	        ajax		: {	

	        				type		: objects.ajax.type, 	
	        				url			: objects.ajax.url,
	        				headers		: (objects.headers != undefined)?objects.headers:{}, 
	        				async		: (objects.async != undefined)?objects.async:true,
	        				data 		: function (data) {
	        					utility.lodderShow ();
	        					dataTable.allBeans = {};
	        					
		            			var info = $('#'+objects.tableID).DataTable().page.info();
		            			info.search  = $('#'+objects.tableID+'_filter input').val();
		            			info.order = $('#'+objects.tableID).DataTable().order();
		            			info.data = objects.ajax.data;
		            			return JSON.stringify(info);
	        				},
	        				dataType 	: (objects.dataType != undefined)?objects.dataType:'json',
	        				cache		: (objects.cache != undefined)?objects.cache:true,
	        				contentType	: (objects.contentType != undefined)?objects.contentType:'application/json; charset=utf-8',
	        				complete: function(response) {
	        					utility.lodderHide ();
	        				}
	        }
	    });
		
		// Add placeholder to the datatable filter option
		$('.dataTables_filter input[type=search]').attr('placeholder','Type to search...');
		$('.dataTables_filter input[type=search]').attr('class', 'form-control');

		// Enable Select2 select for the length option
		$('.dataTables_length select').select2({
			minimumResultsForSearch: Infinity,
			width: 'auto'
		});
		return dataTableObject;
	}
	
	function loadTableWithoutPagination (objConfig) {
		utility.lodderShow ();
		
		var referrer = window.location.pathname;
		if (objConfig.ajax.url.indexOf("?") >= 0) {
			objConfig.ajax.url = objConfig.ajax.url + "referrer="+referrer+"&isAjax="+true;
		} else {
			objConfig.ajax.url = objConfig.ajax.url + "?referrer="+referrer+"&isAjax="+true;
		}
		
		var buttons = objConfig.externalButtons;
		var dataTableObj = $('#'+objConfig.tableID).DataTable({
	        dom			: "Bfrtip",
	        serverSide	: false,
	        paging		: false,
	        searching	: false,
	        columns		: objConfig.columns,
	        buttons		: buttons,
	        ajax		: {	
	        				type		: objConfig.ajax.type, 	// POST or GET request [mandatory field]
	        				url			: objConfig.ajax.url, 	// Request URL [mandatory field]
	        				headers		: (objConfig.headers != undefined)?objConfig.headers:{}, 
	        				async		: (objConfig.async != undefined)?objConfig.async:true,
	        				data 		: function (data) {
	        					utility.lodderShow ();
	        					dataTable.allBeans = {};
	        					
		            			var info = $('#'+objConfig.tableID).DataTable().page.info();
		            			//info.search  = $('#'+objConfig.tableID+'_filter input').val();
		            			//info.order = $('#'+objConfig.tableID).DataTable().order();
		            			info.data = objConfig.ajax.data;
		            			return JSON.stringify(info);
	        				},
	        				dataType 	: (objConfig.dataType != undefined)?objConfig.dataType:'json',
	        				cache		: (objConfig.cache != undefined)?objConfig.cache:true,
	        				contentType	: (objConfig.contentType != undefined)?objConfig.contentType:'application/json; charset=utf-8',
	        				complete: function(response) {
	        					utility.lodderHide ();
	        				}
	        }
	    });
		return dataTableObj;
	}
}

var userInfo = new UserInfo ();

function UserInfo () {
	this.getUserBranchList = getUserBranchList;
	this.setReportMenu = setReportMenu;
	
	function getUserBranchList (id) {
		var objectConfig = {}; 
		objectConfig['type'] = 'GET';
		objectConfig['url'] = serviceURL + "/branch/getBranchMasters";
		objectConfig['data'] = {};
		objectConfig['dataType'] = 'json';
		objectConfig['success'] = function (response) {
			$('#'+id).empty();
			var size = 0;
			var arr = [];
			 $.each(response, function (index, value) {
				 size = size + 1;
				 arr.push(index);
			  });
			 if (size == 1) {
					$.each(response.response, function( index, value ) {
						$('#'+id).append($('<option>', { value: index, text : value }));
					});
					$('#'+id).attr ('readonly', 'readonly');
				} else {
					$('#'+id).append($('<option>', { value: "", text : "SELECT BRANCH" }));
					$.each(response.response, function( index, value ) {
						$('#'+id).append($('<option>', { value: value.id, text: value.name }));
					});
				} 
			 try {
					obj.initAfterSourceBranchLoad (arr);
				} catch (e) { }
		};
		objectConfig['error'] = function (response) {
			utility.viewErrorFooterAlert (response.message);
		};
		ajax.callAjax (objectConfig);
	}
	
	function setReportMenu () {
		var menuHtml = '';
		if (reportCatMenuMap != null && reportCatMenuMap != undefined && reportCatMenuMap != {}) {
			menuHtml = menuHtml + ' <li class="reportMenuLi"> ';
			$.map(reportCatMenuMap, function( value, key ) {
				menuHtml = menuHtml + ' <a href="#"> <i class="fa fa-pencil-square-o"></i> <span style="margin-left:18px;">'+key+'</span><i class="fa fa-angle-left pull-right"></i></a> ';
				$.each( value, function( i, val ) {
					menuHtml = menuHtml + ' <ul class="sidebar-submenu" style="display: none;"> ';
					menuHtml = menuHtml + ' <li><a href="'+serviceURL+'/report/reportParam?reportId='+val.id+'"><i class="fa fa-circle-o"></i>'+val.name+'</a></li> ';
					menuHtml = menuHtml + ' </ul>  ';
				}); 
			});
			menuHtml = menuHtml + ' </li> ';
		}
		
		$('#reportMenuUl').append(menuHtml);
	}
	
}

var utility = new Utility ();
function Utility () {
	
	var contentNumberRegx = /^(?:(?:\+|0{0,2})91(\s*[\ -]\s*)?|[0]?)?[789]\d{9}|(\d[ -]?){10}\d$/;
	var urlRegx = /^((https?):\/\/)?([w|W]{3}\.)+[a-zA-Z0-9\-\.]{3,}\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?$/;
	var sessionTimeOutAlertCalled = false;
	var alphaNumericAllowedRegx = /^[A-Za-z0-9_ \-]+$/;
	var alphaNumericRegx = /^[A-Za-z0-9]+$/;
	var charactersSpaceRegx = /^[a-zA-Z]*$/;
	var alphaNumericspaceRegx = /^[A-Za-z0-9 ]+$/;
	var pincodeRegx = /^[1-9][0-9]{5}$/;
	var numericRegx = /^\d+$/;
	var decimalRegx = /^\d+(\.\d{1,2})?$/;
	var emailRegx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	this.selectAll = selectAll;
	this.showForm = showForm;
	this.showTable = showTable;
	this.lodderShow 	= lodderShow;
	this.lodderHide 	= lodderHide;
	this.scrollToTop = scrollToTop; document.documentElement.scrollTop = 0;
	this.blinkingStart = blinkingStart;
	this.blinkIteration = blinkIteration;
	this.stopBlinking = stopBlinking;
	this.removeWhiteSpace = removeWhiteSpace;
	this.isAlphaNumeric = isAlphaNumeric;  
	this.viewSuccessFooterAlert = viewSuccessFooterAlert; 
	this.viewErrorFooterAlert = viewErrorFooterAlert;
	this.viewFormMessageAlert = viewFormMessageAlert;
	this.isAlphaNumericSpace = isAlphaNumericSpace;
	this.isCharactersSpace = isCharactersSpace;
	this.isNumericContent = isNumericContent;
	this.isJpeg 	= isJpeg;
	this.isPng 		= isPng;
	this.setCookie	    = setCookie;
	this.isValidEmail 	= isValidEmail;
	this.isNumericPincode = isNumericPincode;
	this.isNumeric 		= isNumeric;
	this.isDecimal 		= isDecimal;
	this.onlyNumber     = onlyNumber;
	this.isUrl 			= isUrl;
	this.isEmpty 		= isEmpty;
	this.calculateOffset     = calculateOffset;
	this.checkSession   = checkSession;
	this.getCookie      = getCookie;
	this.sessionExpireCounter = sessionExpireCounter;
	this.keepSignIn = keepSignIn;
	this.allowOnlyNumber = allowOnlyNumber;
	this.isAlphaNumericAllowed = isAlphaNumericAllowed;
	this.imageView = imageView;
	
	function onlyNumber (event) {
		var keyCode = event.which ? event.which : event.keyCode
		var result = ((keyCode >= 48 && keyCode <= 57) ||keyCode==8||keyCode==9);
		if(!result){
			event.preventDefault();
		}
	}
	function selectAll (id,muiltId) {
		var flag = document.getElementById (id).checked;
		if(flag){
			$("#"+muiltId+"> option").prop("selected",true).trigger("change");
			
		}else{
			$("#"+muiltId+"> option").prop("selected",false).trigger("change");;
			$('#'+muiltId).val(null).trigger('change');
		}
	}
	
	function scrollToTop(){
		document.documentElement.scrollTop = 0;
	} 
	
	function showForm () {
		/*$('.new-table').hide();
		$('.new-form').show();
		var index = window.location.href.indexOf("#");
		if(index ==-1){
			window.history.pushState("object or string", "Title", window.location.href+"#"+ Math.random().toString(36).substring(7));
		}else{
			window.history.pushState("object or string", "Title",  window.location.href.substring(0,index)+"#"+ Math.random().toString(36).substring(7));
		}*/
		
	}
	
	function showTable () {
		/*$('.new-table').show();
		$('.new-form').hide();
		var index = window.location.href.indexOf("#");
		if(index ==-1){
			window.history.pushState("object or string", "Title", window.location.href+"#"+ Math.random().toString(36).substring(7));
		}else{
			window.history.pushState("object or string", "Title",  window.location.href.substring(0,index)+"#"+ Math.random().toString(36).substring(7));
		}*/
	}
	
	function imageView(img) {
		var modal = document.getElementById('imageModal');
		var modalImg = document.getElementById("img01");
		var captionText = document.getElementById("imageCaption");
		modal.style.display = "block";
		modalImg.src = img.src;
		modalImg.alt = img.alt;
		captionText.innerHTML = img.alt;
	}
	
	function lodderShow () {
		$('#preloader').show();
		
	}
	
	function lodderHide () {
		$('#preloader').hide();
	}
	
	function blinkingStart(title) {
		originalTitle = document.title;
		blinkTitle = title;
		blinkIteration();
	}
	
	function stopBlinking() {
		if(blinkHandler) {
			clearTimeout(blinkHandler);
		}
		document.title = originalTitle;
	}
	
	function removeWhiteSpace (str) {
		return $.trim (str);
	}
	
	function keepSignIn () {
		var objectConfig = {}; 
		objectConfig['type'] = 'POST';
		objectConfig['url'] = serviceURL + "/keepSignIn";
		objectConfig['data'] = {};
		objectConfig['dataType'] = 'json';
		objectConfig['success'] = function (response) {
			if (response.status == 'SUCCESS') {
				seconds = 60;
				sessionTimeOutAlertCalled = false;
				$('#expireWaring').modal('hide');
				clearTimeout(timer);
				utility.stopBlinking ();
			} 
		};
		objectConfig['error'] = function (response) {
			
		};
		ajax.callAjax (objectConfig);
	}
	
	
	
	var timer = null;
	var seconds = 60;
	function sessionExpireCounter () {
		$('#timer').html(seconds);
		seconds = seconds - 1;
		if (seconds <= 0) {
			clearTimeout(timer);
			return;
		}
		timer = setTimeout('utility.sessionExpireCounter ()', 1000);
	}
	
	function calculateOffset () {
		var serverTime = getCookie('serverTime');
	    serverTime = serverTime==null ? null : Math.abs(serverTime);
	    var clientTimeOffset = (new Date()).getTime() - serverTime;
	    setCookie('clientTimeOffset', clientTimeOffset);
	    utility.checkSession ();
	}
	
	function allowOnlyNumber(evt) {
	    evt = (evt) ? evt : window.event;
	    var charCode = (evt.which) ? evt.which : evt.keyCode;
	    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
	        return false;
	    }
	    return true;
	}
	
	function isAlphaNumericAllowed (str) {
		return alphaNumericAllowedRegx.test(str);
	}
	
	function checkSession () {
		
		if (getCookie('sessionExpiry') == null || getCookie('sessionExpiry') == undefined || getCookie('sessionExpiry') == "") {
			return;
		}
		
		var sessionExpiry = Math.abs(getCookie('sessionExpiry'));
	    var timeOffset = Math.abs(getCookie('clientTimeOffset'));
	    var localTime = (new Date()).getTime();
	    
	    if ((localTime - timeOffset > (sessionExpiry-60000)) && !sessionTimeOutAlertCalled) {
	        sessionTimeOutAlertCalled = true;
	        $('#expireWaring').modal('show');
	        utility.sessionExpireCounter ();
	        utility.blinkingStart ('Session Expire');
	    }
	    
	    if (localTime - timeOffset > (sessionExpiry+1000)) { // 5 extra seconds to make sure
	    	$('#expireWaring').modal('hide');
	    	$('#logout_popup').modal('show');
	    	utility.stopBlinking ();
	    	utility.blinkingStart ('Session Expired');
	    	
	    }  else {
	        setTimeout('utility.checkSession ()', 5000);
	    }
	}
	
	function setCookie(cname, cvalue) {
	    var d = new Date();
	    d.setTime(d.getTime() + (24*60*60*1000));
	    var expires = "expires="+d.toUTCString();
	    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
	}

	function getCookie(cname) {
	    var name = cname + "=";
	    var ca = document.cookie.split(';');
	    for(var i = 0; i < ca.length; i++) {
	        var c = ca[i];
	        while (c.charAt(0) == ' ') {
	            c = c.substring(1);
	        }
	        if (c.indexOf(name) == 0) {
	            return c.substring(name.length, c.length);
	        }
	    }
	    return "";
	}
	
	var originalTitle;
	var blinkTitle;
	var blinkLogicState = false;
	
	

	function blinkIteration() {
		if(blinkLogicState == false) {
			document.title = blinkTitle;
		} else {
			document.title = originalTitle;
		}
		
		blinkLogicState = !blinkLogicState;
		blinkHandler = setTimeout(blinkIteration, 1000);
	}

	function isEmpty (str) {
		return $.trim (str) == "";
	}
	
	function viewSuccessFooterAlert (msg) {
		$("#success-alert-msg").html (msg);
		$("#success-alert-msg").slideDown('slow');
		setTimeout(function() { $("#success-alert-msg").slideUp('slow');  }, 5000);
	}
	
	function viewErrorFooterAlert (msg) {
		$("#error-alert-msg").html (msg);
		$("#error-alert-msg").slideDown('slow');
		setTimeout(function() { $("#error-alert-msg").slideUp('slow');  }, 5000);
	}
	
	function viewFormMessageAlert (id, msg) {
		$(".form-messages-div").hide ();
		$('#'+id+" div").html (msg);
		$('#'+id).fadeIn("slow").delay(1500).fadeOut('slow');
		scrollToTop();
	}
	
	function isAlphaNumeric (str) {
		return alphaNumericRegx.test(str);
	}
	
	function isAlphaNumericSpace (str) {
		return alphaNumericspaceRegx.test(str);
	}
	
	function isCharactersSpace (str) {
		return charactersSpaceRegx.test(str);
	}
	
	function isNumericContent (str) {
		return contentNumberRegx.test(str);
	}
	
	function isValidEmail (str) {
		return emailRegx.test(str);
	}
	
	function isNumericPincode (str) {
		return pincodeRegx.test(str);
	}
	
	function isNumeric (str) {
		return numericRegx.test(str);
	}
	
	function isDecimal (str) {
		return decimalRegx.test(str);
	}
	
	function isJpeg(str) {
		return str.match(/jpg$/i);
	}

	function isPng(str) {
		return str.match(/png$/i);
	}
	
	function isUrl (str) {
		return urlRegx.test(str);
	}
} 

var ajax = new Ajax ();
function Ajax () {
	
	this.callAjax   = callAjax;
	
	function callAjax (objectConfig) {
		if (objectConfig['isLodderRequire'] != false) {
			utility.lodderShow ();
		} else {
			utility.lodderHide ();
		}
		
		var referrer = window.location.pathname;
		if (objectConfig.url.indexOf("?") >= 0) {
			objectConfig.url = objectConfig.url + "&referrer="+referrer+"&isAjax="+true;
		} else {
			objectConfig.url = objectConfig.url + "?referrer="+referrer+"&isAjax="+true;
		}
		
		$.ajax({
			type		: objectConfig.type, 	
			url			: objectConfig.url, 
			headers		: (objectConfig.headers != undefined)?objectConfig.headers:{}, 
			async		: (objectConfig.async != undefined)?objectConfig.async:true,
			processData	: (objectConfig.processData != undefined)?objectConfig.processData:true,
			data 		: (objectConfig.data != undefined)?objectConfig.data:{},
			dataType 	: (objectConfig.dataType != undefined)?objectConfig.dataType:'json',
			cache		: (objectConfig.cache != undefined)?objectConfig.cache:true,
			contentType	: (objectConfig.contentType != undefined)?objectConfig.contentType:'application/json; charset=utf-8',
			enctype     : (objectConfig.enctype != undefined)?objectConfig.enctype:'application/json',
			success		: function(data) {
				//Handle success status and do more
				objectConfig.success(data); 
			},   
			error: function(data, textStatus, jqXHR) {
	            //Handle error status and do more
				try {
					objectConfig.error(data, textStatus, jqXHR)
				} catch (e) {
					console.log ("Ajax Error: ERROR handler not provided ("+data+")");
					console.log(data);
					utility.viewErrorFooterAlert ("Ajax Error: ERROR handler not provided [" + e.message+" ]");
				}
			},
			complete: function(response) {
				utility.lodderHide ();
		    }
		});
	}
}