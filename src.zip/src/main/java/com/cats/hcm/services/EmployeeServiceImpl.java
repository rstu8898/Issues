package com.cats.hcm.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cats.hcm.bussinessObjects.Address;
import com.cats.hcm.bussinessObjects.Education;
import com.cats.hcm.bussinessObjects.Employee;
import com.cats.hcm.bussinessObjects.EmployeeBO;
import com.cats.hcm.bussinessObjects.EmployeeChild;
import com.cats.hcm.bussinessObjects.Employment;
import com.cats.hcm.bussinessObjects.PastEmployment;
import com.google.gson.Gson;

import xyz.morphia.Datastore;
import xyz.morphia.query.Query;

@Service
public class EmployeeServiceImpl implements EmployeeServiceInterface{

	@Autowired
	private Datastore datastore;
	
	private Gson gson;
	
	private static final Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	
	@SuppressWarnings("deprecation")
	@Override
	public EmployeeBO getEmployeeBO(String EmployeeId) {
		logger.info("=======getEmployeeBO======="+EmployeeId);
		EmployeeBO employeeBO = new EmployeeBO();
		
		List<Address> addressList = datastore.find(Address.class, "employeeId", EmployeeId).asList();
		List<Education> educationList = datastore.find(Education.class, "employeeId", EmployeeId).asList();
		List<PastEmployment> pastEmploymentList = datastore.find(PastEmployment.class, "employeeId", EmployeeId).asList();
		List<EmployeeChild> employeeChildList = datastore.find(EmployeeChild.class, "employeeId", EmployeeId).asList();
		Employee employee = datastore.find(Employee.class, "employeeId", EmployeeId).asList().get(0);
		
		employeeBO.setAddress(addressList);
		employeeBO.setEducationDetails(educationList);	
		employeeBO.setPastEmployments(pastEmploymentList);
		employeeBO.setChilds(employeeChildList);
		employeeBO.setEmployeeId(employee.getEmployeeId());
		employeeBO.setFatherOrHusbandName(employee.getFatherOrHusbandName());
		employeeBO.setFirstName(employee.getFirstName());
		employeeBO.setLastName(employee.getLastName());
		employeeBO.setMotherName(employee.getMotherName());
		employeeBO.setContactNumber(employee.getContactNumber());
		employeeBO.setEmailId(employee.getEmailId());
		employeeBO.setPanCardNumber(employee.getPanCardNumber());
		employeeBO.setAadharNumber(employee.getAadharNumber());
		employeeBO.setHobbies(employee.getHobbies());
		employeeBO.setInterests(employee.getInterests());
		employeeBO.setSpouseName(employee.getSpouseName());
		employeeBO.setSpouseAge(employee.getSpouseAge());
		employeeBO.setSpouseGender(employee.getSpouseGender());
		employeeBO.setKinName(employee.getKinName());
		employeeBO.setKinAge(employee.getKinAge());
		employeeBO.setKinGender(employee.getKinGender());
		employeeBO.setEmergencyContactName(employee.getEmergencyContactName());
		employeeBO.setEmergencyContactNo(employee.getEmergencyContactNo());
		employeeBO.setEmergencyContactRelationship(employee.getEmergencyContactRelationship());
		employeeBO.setMaritalStatusId(employee.getMaritalStatusId());
		employeeBO.setEmpGender(employee.getEmpGender());
		employeeBO.setCurrentDepartment(employee.getCurrentDepartment());
		employeeBO.setCurrentDesignation(employee.getCurrentDesignation());
		employeeBO.setCurrentJobLocation(employee.getCurrentJobLocation());
		employeeBO.setJobType(employee.getJobType());
		employeeBO.setClientName(employee.getClientName());
		employeeBO.setBloodGroup(employee.getBloodGroup());
		employeeBO.setMedicalCase(employee.getMedicalCase());
		employeeBO.setTechCertificationOne(employee.getTechCertificationOne());
		employeeBO.setTechCertificationTwo(employee.getTechCertificationTwo());
		
		employeeBO.setEmpPhotoFile(employee.getEmpPhotoFile());
		employeeBO.setEmpPanFile(employee.getEmpPanFile());
		employeeBO.setEmpAadharFile(employee.getEmpAadharFile());
		employeeBO.setEmpEducationalFile(employee.getEmpEducationalFile());
		employeeBO.setEmpExperienceFile(employee.getEmpExperienceFile());



		
		return employeeBO;
	}

	@SuppressWarnings("unlikely-arg-type")
	@Override
	public Boolean deleteEmployeeDetails(String EmployeeId) {
		
		//Deleting Education Details
		/*Query<Education> queryEducation = datastore.createQuery(Education.class);
		queryEducation.field("employeeId").equals(EmployeeId);
		List<Education> educations = queryEducation.asList();
		for(Education education : educations) {
			datastore.delete(education);
		}*/
		//datastore.findAndDelete(queryEducation);
		datastore.delete(datastore.createQuery(Employee.class).filter("employeeId", EmployeeId));
		datastore.delete(datastore.createQuery(Address.class).filter("employeeId", EmployeeId));
		datastore.delete(datastore.createQuery(PastEmployment.class).filter("employeeId", EmployeeId));
		datastore.delete(datastore.createQuery(EmployeeChild.class).filter("employeeId", EmployeeId));

		//datastore.delete(datastore.createQuery(Education.class).filter("employeeId", EmployeeId));
		
		/*//Deleting Employment Details
		Query<Employment> queryEmployment = datastore.createQuery(Employment.class);
		queryEmployment.field("employeeId").equals(EmployeeId);
		for (Employment employment : queryEmployment) {
			datastore.findAndDelete(queryEmployment);
		}*/		
		
		//Deleting PastEmployment Details
		/*Query<PastEmployment> queryPastEmployment = datastore.createQuery(PastEmployment.class);
		queryPastEmployment.field("employeeId").equals(EmployeeId);
		for (PastEmployment pastEmployment : queryPastEmployment) {
			datastore.findAndDelete(queryPastEmployment);
		}*/
		
		/*//Deleting Address Details
		Query<Address> queryAddress = datastore.createQuery(Address.class);
		queryAddress.field("employeeId").equals(EmployeeId);
		for (Address address : queryAddress) {
			datastore.findAndDelete(queryAddress);
		}*/
		
		//Deleting Employee
		/*Query<Employee> queryEmployee = datastore.createQuery(Employee.class);
		queryEmployee.field("employeeId").equals(EmployeeId);
		for (Employee employee : queryEmployee) {
			datastore.findAndDelete(queryEmployee);			
		}*/
		
		//Deleting Employee Child
		/*Query<EmployeeChild> queryEmployeeChild = datastore.createQuery(EmployeeChild.class);
		queryEmployeeChild.field("employeeId").equals(EmployeeId);
		for (EmployeeChild employeeChild : queryEmployeeChild) {
			datastore.findAndDelete(queryEmployeeChild);
		}*/
	
		/*//Deleting Employee Education
		Query<Education> queryEmployeeEducation = datastore.createQuery(Education.class);
		queryEmployeeEducation.field("employeeId").equals(EmployeeId);
		for (Education education : queryEmployeeEducation) {
			datastore.findAndDelete(queryEmployeeEducation);
		}*/

		return true;
	}
}
