package com.cats.hcm.services;

import com.cats.hcm.bussinessObjects.EmployeeBO;

public interface EmployeeServiceInterface {

	public EmployeeBO getEmployeeBO(String EmployeeId);
	
	public Boolean deleteEmployeeDetails(String EmployeeId);
}
