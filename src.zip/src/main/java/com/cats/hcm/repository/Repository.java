package com.cats.hcm.repository;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cats.hcm.bussinessObjects.Address;
import com.cats.hcm.bussinessObjects.Education;
import com.cats.hcm.bussinessObjects.Employee;
import com.cats.hcm.bussinessObjects.EmployeeBO;
import com.cats.hcm.bussinessObjects.EmployeeChild;
import com.cats.hcm.bussinessObjects.PastEmployment;
import com.cats.hcm.bussinessObjects.MaritalStatus;
import com.cats.hcm.bussinessObjects.State;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

import xyz.morphia.Datastore;
import xyz.morphia.Morphia;

@Service
public class Repository {
	
	private static final Logger logger = LoggerFactory.getLogger(Repository.class);


	@Autowired
	EmployeeRepositoryImpl employeeRepositoryImpl;

	@Autowired
	AddressRepositoryImpl addressRepositoryImpl;

	@Autowired
	EducationRepositoryImpl educationRepositoryImpl;

	@Autowired
	EmployeeChildRepositoryImpl employeeChildRepositoryImpl;

	@Autowired
	StateRepositoryImpl stateRepositoryImpl;
	
	@Autowired
	PastEmploymentRepositoryImpl pastEmploymentRepositoryImpl;

	// Logger logger =
	// LoggerFactory.getILoggerFactory().getLogger(Repository.class);
	
	
	

	
	public void addToDataBase(EmployeeBO employeeBO)
			throws SecurityException, ClassNotFoundException, IllegalArgumentException, IllegalAccessException {
		logger.info("=======addToDataBase========");
		Employee employee = new Employee();
		employee.setEmployeeId(employeeBO.getEmployeeId());
		employee.setFatherOrHusbandName(employeeBO.getFatherOrHusbandName());
		employee.setFirstName(employeeBO.getFirstName());
		employee.setLastName(employeeBO.getLastName());
		employee.setMotherName(employeeBO.getMotherName());
		employee.setContactNumber(employeeBO.getContactNumber());
		employee.setEmailId(employeeBO.getEmailId());
		employee.setPanCardNumber(employeeBO.getPanCardNumber());
		employee.setAadharNumber(employeeBO.getAadharNumber());
		employee.setHobbies(employeeBO.getHobbies());
		employee.setInterests(employeeBO.getInterests());
		employee.setSpouseName(employeeBO.getSpouseName());
		employee.setSpouseAge(employeeBO.getSpouseAge());
		employee.setSpouseGender(employeeBO.getSpouseGender());
		employee.setKinName(employeeBO.getKinName());
		employee.setKinAge(employeeBO.getKinAge());
		employee.setKinGender(employeeBO.getKinGender());
		employee.setEmergencyContactName(employeeBO.getEmergencyContactName());
		employee.setEmergencyContactNo(employeeBO.getEmergencyContactNo());
		employee.setEmergencyContactRelationship(employeeBO.getEmergencyContactRelationship());
		employee.setMaritalStatusId(employeeBO.getMaritalStatusId());
		employee.setEmpGender(employeeBO.getEmpGender());

		employee.setCurrentDepartment(employeeBO.getCurrentDepartment());
		employee.setCurrentDesignation(employeeBO.getCurrentDesignation());
		employee.setCurrentJobLocation(employeeBO.getCurrentJobLocation());
		employee.setJobType(employeeBO.getJobType());
		employee.setClientName(employeeBO.getClientName());
		employee.setBloodGroup(employeeBO.getBloodGroup());
		employee.setMedicalCase(employeeBO.getMedicalCase());
		employee.setTechCertificationOne(employeeBO.getTechCertificationOne());
		employee.setTechCertificationTwo(employeeBO.getTechCertificationTwo());
		
		employee.setEmpPhotoFile(employeeBO.getEmpPhotoFile());
		employee.setEmpPanFile(employeeBO.getEmpPanFile());
		employee.setEmpAadharFile(employeeBO.getEmpAadharFile());
		employee.setEmpEducationalFile(employeeBO.getEmpEducationalFile());
		employee.setEmpExperienceFile(employeeBO.getEmpExperienceFile());

		employee.setCreatedBy(employeeBO.getCreatedBy());
		employee.setCreatedOn(employeeBO.getCreatedOn());
		employee.setEmpDob(employeeBO.getEmpDob());
		employeeRepositoryImpl.create(employee);

		/*
		 * Morphia morphia = new Morphia(); MongoClientURI uri = new MongoClientURI(
		 * "mongodb://pareshc:catsuser@mongodb-835-0.cloudclusters.net/?authSource=admin"
		 * ); String databaseName = "hcm-db"; MongoClient mongoClient = new
		 * MongoClient(uri); Datastore datastore = morphia.createDatastore(mongoClient,
		 * databaseName);
		 */

		Field[] fields = Class.forName("com.cats.hcm.bussinessObjects.EmployeeBO").getDeclaredFields();
		/*String id=employeeBO.getEmployeeId();
		try {
		Field fieldOne = Class.forName("com.cats.hcm.bussinessObjects.EmployeeBO").getDeclaredField("address");
		addToEmployeeDatabase(id, Address.class, fieldOne);
		} catch (Exception e) {
		// log 
		// throw a custom exception, if required
		}*/
		/*
		 * String id=employeeBO.getEmployeeId(); try { Field fieldOne =
		 * Class.forName("com.cats.hcm.bussinessObjects.EmployeeBO").getDeclaredField(
		 * "address"); addToEmployeeDatabase(id, Address.class, fieldOne); } catch
		 * (Exception e) { // log // throw a custom exception, if required }
		 */

		for (Field field : fields) {
			if (Modifier.isPrivate(field.getModifiers())) {
				field.setAccessible(true);
				System.out.println(field.getName() + " : " + field.get(employeeBO));

				Object object = field.get(employeeBO);

				if (field.getName().equals("address")) {
					List<Address> addresses = (List<Address>) object;
					if (addresses != null) {
						for (Address address : addresses) {
							address.setEmployeeId(employeeBO.getEmployeeId());
							// datastore.save(address);
							addressRepositoryImpl.create(address);
						}
						logger.info("=====Address Saved======");
					}
				} else if (field.getName().equals("employments")) {
					Set<PastEmployment> employments = (Set<PastEmployment>) object;
					if (employments != null) {
						for (PastEmployment employment : employments) {
							// datastore.save(employment);
						}
						logger.info("======Employment Saved=======");
					}
				} else if (field.getName().equals("educationDetails")) {
					List<Education> eductionDetails = (List<Education>) object;
					if (eductionDetails != null) {
						for (Education education : eductionDetails) {
							education.setEmployeeId(employeeBO.getEmployeeId());
							educationRepositoryImpl.create(education);
						}
						logger.info("======Education Saved=======");
					}
				} else if (field.getName().equals("childs")) {

					List<EmployeeChild> employeeChilds = (List<EmployeeChild>) object;
					if (employeeChilds != null) {
						for (EmployeeChild employeeChild : employeeChilds) {
							employeeChild.setEmployeeId(employeeBO.getEmployeeId());
							employeeChildRepositoryImpl.create(employeeChild);
						}
						logger.info("======Employee Child Saved=======");
					}
				}
				 else if (field.getName().equals("pastEmployments")) {

						List<PastEmployment> pastEmployments = (List<PastEmployment>) object;
						if (pastEmployments != null) {
							for (PastEmployment pastEmployment : pastEmployments) {
								pastEmployment.setEmployeeId(employeeBO.getEmployeeId());
								pastEmploymentRepositoryImpl.create(pastEmployment);
							}
							logger.info("======Past Employment Saved=======");
						}
					}
			}
			logger.info("========Employee Saved=========");
		}
	}

	/*public void addToEmployeeDatabase(String id, Class _className, Object valueObject) {
		Object _object = Class.forName(_className.getName()).newInstance();
		List<_object> classList = (List<_object>) valueObject;
		}*/
	
	// datastore.save(employee);
	/*
	 * System.out.println("========Employee Saved========="); } }
	 */

	/*public static void main(String args[]) throws SecurityException,
	  ClassNotFoundException {
	  
	  Field[] fields =
	  Class.forName("com.cats.hcm.bussinessObjects.EmployeeBO").getDeclaredFields()
	  ; String id="101"; try { Field fieldOne =
	  Class.forName("com.cats.hcm.bussinessObjects.EmployeeBO").getDeclaredField(
	  "address"); addToEmployeeDatabase(id, Address.class, fieldOne); } catch
	  (Exception e) { // log // throw a custom exception, if required } }

	public void addToEmployeeDatabase(String id, Class _className, Object valueObject) { // create audit log
		// Class.forName(_className.getName()).newInstance()

		Object _object = Class.forName(_className.getName()).newInstance();
		List<_object> classList = (List<_object>) valueObject;
	}

	public static void main(String args[])
			throws SecurityException, ClassNotFoundException, IllegalArgumentException, IllegalAccessException {

		System.out.println("======started======");
		Morphia morphia = new Morphia();
		MongoClientURI uri = new MongoClientURI(
				"mongodb://pareshc:catsuser@mongodb-835-0.cloudclusters.net/?authSource=admin");
		String databaseName = "hcm-db";
		MongoClient mongoClient = new MongoClient(uri);
		Datastore datastore = morphia.createDatastore(mongoClient, databaseName);

		Employee employee = new Employee();
		employee.setEmployeeId("108");
		employee.setFirstName("Nitesh");
		employee.setFatherName("Meghnath");
		employee.setLastName("Divekar");

		EmployeeBO employeeBO = new EmployeeBO();

		Address address1 = new Address();
		address1.setEmployeeId(employee.getEmployeeId());
		address1.setAddressLine1("kashintha house");
		address1.setAddressLine2("Mankhurd");

		Address address2 = new Address();
		address2.setEmployeeId(employee.getEmployeeId());
		address2.setAddressLine1("catseye");
		address2.setAddressLine2("mahape");

		Employment employment1 = new Employment();
		employment1.setEmployeeId(employee.getEmployeeId());
		employment1.setCompanyName("abc");

		Employment employment2 = new Employment();
		employment2.setEmployeeId(employee.getEmployeeId());
		employment2.setCompanyName("xyz");

		Set<Address> addressDetails = new HashSet<>();
		addressDetails.add(address1);
		addressDetails.add(address2);
		employeeBO.setAddress(addressDetails);

		Set<Employment> employemntDetails = new HashSet<>();
		employemntDetails.add(employment1);
		employemntDetails.add(employment2);
		employeeBO.setEmployments(employemntDetails);

		Field[] fields = Class.forName("com.cats.hcm.bussinessObjects.EmployeeBO").getDeclaredFields();
		for (int i = 0; i < fields.length; i++) {
			System.out.println(fields[i].getName());
		}

		for (Field field : fields) {
			if (Modifier.isPrivate(field.getModifiers())) {
				field.setAccessible(true);
				System.out.println(field.getName() + " : " + field.get(employeeBO));

				Object object = field.get(employeeBO);

				if (field.getName().equals("address")) {
					Set<Address> addresses = (Set<Address>) object;
					for (Address address : addresses) {
						datastore.save(address);
					}
					System.out.println("=====Address Saved======");
				} else if (field.getName().equals("employments")) {
					Set<Employment> employments = (Set<Employment>) object;
					for (Employment employment : employments) {
						datastore.save(employment);
					}
					System.out.println("======Employment Saved=======");
				}

				if (object instanceof Address) {
					Address address = (Address) object;
					datastore.save(address);
					System.out.println("=====Address Saved======");
				} else if (object instanceof Employment) {
					Employment employment = (Employment) object;
					datastore.save(employment);
					System.out.println("======Employment Saved=======");
				}

			}
		}
		datastore.save(employee);
		System.out.println("====saved=====");
	}*/

}
