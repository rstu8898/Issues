package com.cats.hcm.repository;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cats.hcm.bussinessObjects.Education;
import com.cats.hcm.bussinessObjects.Education;
import com.cats.hcm.bussinessObjects.Employee;
import com.mongodb.WriteResult;

import xyz.morphia.Datastore;
import xyz.morphia.Key;
import xyz.morphia.query.UpdateOperations;
import xyz.morphia.query.UpdateResults;

@Repository
public class EducationRepositoryImpl {

	@Autowired
	private Datastore datastore;
	
	public Key<Education> create(Education education) {
		return datastore.save(education);
	}

	public Education read(ObjectId id) {
		return datastore.get(Education.class, id);
	}

	public UpdateResults update(Education Education, UpdateOperations<Education> operations) {
		return datastore.update(Education, operations);
	}

	public WriteResult delete(Education Education) {
		return datastore.delete(Education);
	}

	public UpdateOperations<Education> createOperations() {
		return datastore.createUpdateOperations(Education.class);
	}
}
