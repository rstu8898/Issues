package com.cats.hcm.repository;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cats.hcm.bussinessObjects.Education;
import com.cats.hcm.bussinessObjects.Education;
import com.cats.hcm.bussinessObjects.Employee;
import com.cats.hcm.bussinessObjects.PastEmployment;
import com.mongodb.WriteResult;

import xyz.morphia.Datastore;
import xyz.morphia.Key;
import xyz.morphia.query.UpdateOperations;
import xyz.morphia.query.UpdateResults;

@Repository
public class PastEmploymentRepositoryImpl {

	@Autowired
	private Datastore datastore;
	
	public Key<PastEmployment> create(PastEmployment pastEmployment) {
		return datastore.save(pastEmployment);
	}

	public PastEmployment read(ObjectId id) {
		return datastore.get(PastEmployment.class, id);
	}

	public UpdateResults update(PastEmployment pastEmployment, UpdateOperations<PastEmployment> operations) {
		return datastore.update(pastEmployment, operations);
	}

	public WriteResult delete(PastEmployment pastEmployment) {
		return datastore.delete(pastEmployment);
	}

	public UpdateOperations<PastEmployment> createOperations() {
		return datastore.createUpdateOperations(PastEmployment.class);
	}
}
