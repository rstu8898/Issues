package com.cats.hcm.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cats.hcm.bussinessObjects.Address;
import com.cats.hcm.bussinessObjects.MaritalStatus;
import com.cats.hcm.bussinessObjects.State;

import xyz.morphia.Datastore;
import xyz.morphia.Key;

@Repository
public class MaritalStatusRepositoryImpl {

	@Autowired
	private Datastore datastore;
	
	public Key<MaritalStatus> create(MaritalStatus maritalStatus) {
		return datastore.save(maritalStatus);
	}
	
	public List<MaritalStatus> readAll() {

		return datastore.find(MaritalStatus.class).asList();
	}
}
