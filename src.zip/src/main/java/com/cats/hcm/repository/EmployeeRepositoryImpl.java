package com.cats.hcm.repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cats.hcm.bussinessObjects.Employee;
import com.cats.hcm.bussinessObjects.EmployeeChild;
import com.cats.hcm.bussinessObjects.State;
import com.cats.hcm.entity.EmployeeEntity;
import com.mongodb.WriteResult;

import xyz.morphia.Datastore;
import xyz.morphia.Key;
import xyz.morphia.query.UpdateOperations;
import xyz.morphia.query.UpdateResults;

@Repository
public class EmployeeRepositoryImpl {

	@Autowired
	private Datastore datastore;

	public Key<Employee> create(Employee employeeEntity) {
		return datastore.save(employeeEntity);
	}

	public Employee read(ObjectId id) {
		return datastore.get(Employee.class, id);
	}
	
	public UpdateResults update(Employee employeeEntity, UpdateOperations<Employee> operations) {
		return datastore.update(employeeEntity, operations);
	}

	public WriteResult delete(Employee employeeEntity) {
		return datastore.delete(employeeEntity);
	}

	public UpdateOperations<Employee> createOperations() {
		return datastore.createUpdateOperations(Employee.class);
	}
	
	public List<Employee> readAll() {

		return datastore.find(Employee.class).asList();
	}
}
