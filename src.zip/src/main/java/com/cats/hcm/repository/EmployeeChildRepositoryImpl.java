package com.cats.hcm.repository;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cats.hcm.bussinessObjects.EmployeeChild;
import com.cats.hcm.bussinessObjects.EmployeeChild;
import com.cats.hcm.bussinessObjects.Employee;
import com.mongodb.WriteResult;

import xyz.morphia.Datastore;
import xyz.morphia.Key;
import xyz.morphia.query.UpdateOperations;
import xyz.morphia.query.UpdateResults;

@Repository
public class EmployeeChildRepositoryImpl {

	@Autowired
	private Datastore datastore;
	
	public Key<EmployeeChild> create(EmployeeChild employeeChild) {
		return datastore.save(employeeChild);
	}

	public EmployeeChild read(ObjectId id) {
		return datastore.get(EmployeeChild.class, id);
	}

	public UpdateResults update(EmployeeChild employeeChild, UpdateOperations<EmployeeChild> operations) {
		return datastore.update(employeeChild, operations);
	}

	public WriteResult delete(EmployeeChild employeeChild) {
		return datastore.delete(employeeChild);
	}

	public UpdateOperations<EmployeeChild> createOperations() {
		return datastore.createUpdateOperations(EmployeeChild.class);
	}
}
