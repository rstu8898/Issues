package com.cats.hcm.repository;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cats.hcm.bussinessObjects.Address;
import com.cats.hcm.bussinessObjects.Employee;
import com.mongodb.WriteResult;

import xyz.morphia.Datastore;
import xyz.morphia.Key;
import xyz.morphia.query.UpdateOperations;
import xyz.morphia.query.UpdateResults;

@Repository
public class AddressRepositoryImpl {

	@Autowired
	private Datastore datastore;

	public Key<Address> create(Address address) {
		return datastore.save(address);
	}

	public Address read(ObjectId id) {
		return datastore.get(Address.class, id);
	}

	public List<Address> readAll() {

		return datastore.find(Address.class).asList();
	}

	public UpdateResults update(Address address, UpdateOperations<Address> operations) {
		return datastore.update(address, operations);
	}

	public WriteResult delete(Address address) {
		return datastore.delete(address);
	}

	public UpdateOperations<Address> createOperations() {
		return datastore.createUpdateOperations(Address.class);
	}
}
