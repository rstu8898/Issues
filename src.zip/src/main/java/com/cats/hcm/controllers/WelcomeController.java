package com.cats.hcm.controllers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WelcomeController {

	// inject via application.properties
	@Value("${welcome.message:test}")
	private String message = "Hello World";

	@RequestMapping("/")
	public String welcome(Map<String, Object> model) {
		System.out.println("============");
		//model.put("message", this.message);
		//return "welcome";
		return "index";
	}
	
	@RequestMapping("/dashboard")
	public String getDashboard(Map<String, Object> model) {
		System.out.println("======dashboard======");
		//model.put("message", this.message);
		//return "welcome";
		return "dashboard";
	}
	
	@RequestMapping("/apps-employee")
	public String getEmployee(Map<String, Object> model) {
		System.out.println("======employee======");
		//model.put("message", this.message);
		//return "welcome";
		return "apps-employee";
	}
	
	

}