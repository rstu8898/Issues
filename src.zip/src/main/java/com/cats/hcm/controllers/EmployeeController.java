package com.cats.hcm.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cats.hcm.bussinessObjects.Address;
import com.cats.hcm.bussinessObjects.Employee;
import com.cats.hcm.bussinessObjects.EmployeeBO;
import com.cats.hcm.bussinessObjects.MaritalStatus;
import com.cats.hcm.bussinessObjects.State;
import com.cats.hcm.repository.EmployeeRepositoryImpl;
import com.cats.hcm.repository.MaritalStatusRepositoryImpl;
import com.cats.hcm.repository.Repository;
import com.cats.hcm.repository.StateRepositoryImpl;
import com.cats.hcm.services.EmployeeServiceImpl;
import com.google.gson.Gson;

@Controller
@RequestMapping("/employee")
public class EmployeeController {
	
	private static final Logger logger = LoggerFactory.getLogger(Repository.class);

	@Autowired
	Repository repository;
	
	@Autowired
	StateRepositoryImpl stateRepositoryImpl;
	
	@Autowired
	MaritalStatusRepositoryImpl maritalStatusRepositoryImpl;
	
	@Autowired
	EmployeeRepositoryImpl employeeRepositoryImpl;
	
	@Autowired
	EmployeeServiceImpl employeeServiceImpl;
	
	
	@RequestMapping("/add")
	/* public String getEmployeeAddPage(Map<String, Object> model) { */
	public ModelAndView getEmployeeAddPage(ModelMap model) {
		logger.info("======getEmployeeAddPage======");
		//model.put("message", this.message);
		//return "welcome";
		
		List<State> stateList = stateRepositoryImpl.readAll();
		List<MaritalStatus> maritalStatusList = maritalStatusRepositoryImpl.readAll();

		
		
		/*Map<String, String> stateList = new HashMap<>();
		stateList.put("1", "Maharshtra");
		stateList.put("2", "Gujrat");
		stateList.put("3", "Rajsthan");
		stateList.put("4", "Goa");*/
		
		//model.addAttribute(new Employee());
		model.addAttribute(new EmployeeBO());
		model.addAttribute("stateList", stateList);
		model.addAttribute("maritalStatusList", maritalStatusList);
		//return "apps-add-employee";
		//return new ModelAndView("apps-add-employee");
		return new ModelAndView("apps-add-employee", "employee", new EmployeeBO());
	}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("employee")EmployeeBO employeeBO, @RequestParam("employeePhotoFile") MultipartFile empPhotoFile, @RequestParam("employeePanFile") MultipartFile empPanFile, @RequestParam("employeeAadharFile") MultipartFile empAadharFile, @RequestParam("employeeEducationalFile") MultipartFile empEducationalFile, @RequestParam("employeeExperienceFile") MultipartFile empExperienceFile, BindingResult bindingResult,ModelMap model) throws SecurityException, ClassNotFoundException, IllegalArgumentException, IllegalAccessException, IOException {
		
		logger.info("==========="+new Gson().toJson(employeeBO));
		/*
		 * Set<Address> set = employee.getAddress(); for(Address address : set) {
		 * System.out.println("==============="+address.getAddressLine1()); }
		 */
		
		logger.info("========Employee ID========"+employeeBO.getEmployeeId());
		logger.info("========empPhotoFile=========="+empPhotoFile.getBytes());
		employeeBO.setEmpPhotoFile(empPhotoFile.getBytes());
		employeeBO.setEmpPanFile(empPanFile.getBytes());
		employeeBO.setEmpAadharFile(empAadharFile.getBytes());
		employeeBO.setEmpEducationalFile(empEducationalFile.getBytes());
		employeeBO.setEmpExperienceFile(empExperienceFile.getBytes());
		/*employeeBO.setAadharNumber(aadharNumber);
		employeeBO.setEmpEducationalFile(empEducationalFile);
		employeeBO.setEmpExpericenceFile(aadharNumber);
*/
		repository.addToDataBase(employeeBO);
		
		model.addAttribute("saveStatus", "Record Added Successfully!");
		
		ModelAndView modelAndView = new ModelAndView("redirect:/employee/employeeDataTable");
		modelAndView.addObject("saveStatus", "Record Added Successfully!");
		
		return modelAndView;
		
		//return new ModelAndView("redirect:/employee/employeeDataTable");
		//return "redirect:/employee/employeeDataTable";
	}
	
	@RequestMapping(value="/update", method=RequestMethod.POST)
	public String updateEmployee(@ModelAttribute("employee")EmployeeBO employeeBO, @RequestParam("employeePhotoFile") MultipartFile empPhotoFile, @RequestParam("employeePanFile") MultipartFile empPanFile, @RequestParam("employeeAadharFile") MultipartFile empAadharFile, @RequestParam("employeeEducationalFile") MultipartFile empEducationalFile, @RequestParam("employeeExperienceFile") MultipartFile empExperienceFile, BindingResult bindingResult,ModelMap model) throws SecurityException, ClassNotFoundException, IllegalArgumentException, IllegalAccessException, IOException {
		
		logger.info("==========="+new Gson().toJson(employeeBO));
		logger.info("========Employee ID========"+employeeBO.getEmployeeId());
		logger.info("========empPhotoFile=========="+empPhotoFile.getBytes());
		employeeBO.setEmpPhotoFile(empPhotoFile.getBytes());
		employeeBO.setEmpPanFile(empPanFile.getBytes());
		employeeBO.setEmpAadharFile(empAadharFile.getBytes());
		employeeBO.setEmpEducationalFile(empEducationalFile.getBytes());
		employeeBO.setEmpExperienceFile(empExperienceFile.getBytes());
		/*
		 * Set<Address> set = employee.getAddress(); for(Address address : set) {
		 * System.out.println("==============="+address.getAddressLine1()); }
		 */
		
		//Deleting Existing Employee
		Boolean isDeleted = employeeServiceImpl.deleteEmployeeDetails(employeeBO.getEmployeeId());
		if(isDeleted) {
			repository.addToDataBase(employeeBO);
		}
		
		model.addAttribute("saveStatus", "True");
		//return new ModelAndView("apps-add-employee");
		return "redirect:/employee/employeeDataTable";
	}
	
	@RequestMapping("/employeeDataTable")
	/* public String getEmployeeAddPage(Map<String, Object> model) { */
	public ModelAndView getEmployeeDataTablePage(ModelMap model) {
		logger.info("======getEmployeeDataTablePage======");
		
		
		List<Employee> employeeList = employeeRepositoryImpl.readAll();
		
		logger.info("========EmployeeList========="+new Gson().toJson(employeeList));
		
		model.addAttribute(new EmployeeBO());
		model.addAttribute("employeeList", employeeList);
		//return "apps-add-employee";
		//return new ModelAndView("apps-add-employee");
		return new ModelAndView("apps-employee", "employee", new EmployeeBO());
	}
	
	@RequestMapping("/modifyPage")
	public ModelAndView getEmployeeModifyPage(@RequestParam("employeeId") String employeeId, ModelMap model) {
		logger.info("========getEmployeeModifyPage====EmployeeID:===="+employeeId);
		List<State> stateList = stateRepositoryImpl.readAll();
		List<MaritalStatus> maritalStatusList = maritalStatusRepositoryImpl.readAll();

		model.addAttribute("stateList", stateList);
		model.addAttribute("maritalStatusList", maritalStatusList);
					
		EmployeeBO employeeBO = employeeServiceImpl.getEmployeeBO(employeeId);
		
		File filephoto = new File("/cats/data/hcm/"+employeeBO.getEmployeeId()+" _photo.png");
		File filepan = new File("/cats/data/hcm/"+employeeBO.getEmployeeId()+"_Pan.doc");
		File fileaadhar = new File("/cats/data/hcm/"+employeeBO.getEmployeeId()+"_Aadhar.doc");
		File fileeducational = new File("/cats/data/hcm/"+employeeBO.getEmployeeId()+"_Education.doc");
		File fileexperience = new File("/cats/data/hcm/"+employeeBO.getEmployeeId()+"_Experience.doc");

		
		try {
			filephoto.createNewFile();
			filepan.createNewFile();
			fileaadhar.createNewFile();
			fileeducational.createNewFile();
			fileexperience.createNewFile();
			FileOutputStream f1 = new FileOutputStream(filephoto);
			FileOutputStream f2 = new FileOutputStream(filepan);
			FileOutputStream f3 = new FileOutputStream(fileaadhar);
			FileOutputStream f4 = new FileOutputStream(fileeducational);
			FileOutputStream f5 = new FileOutputStream(fileexperience);
			f1.write(employeeBO.getEmpPhotoFile());
			f2.write(employeeBO.getEmpPanFile());
			f3.write(employeeBO.getEmpAadharFile());
			f4.write(employeeBO.getEmpEducationalFile());
			f5.write(employeeBO.getEmpExperienceFile());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//employeeBO.setState(stateList);
		return new ModelAndView("apps-mod-employee", "employee", employeeBO);
	}

	@RequestMapping("/delete")
	public String deleteEmployee(@RequestParam("employeeId") String employeeId) {
		logger.info("========deleteEmployee===EmployeeID:===="+employeeId);
		//employeeRepositoryImpl.delete(employeeServiceImpl.getEmployeeBO(employeeId));
		Boolean isDeleted = employeeServiceImpl.deleteEmployeeDetails(employeeId);
		if(isDeleted) {
			logger.info("========Employee Record Deleted===EmployeeID:===="+employeeId);
		}
		return "redirect:/employee/employeeDataTable";
	}
	/*@RequestMapping("/employeeDataByEmpId")
	 public String getEmployeeAddPage(Map<String, Object> model) { 
	public ModelAndView getEmployeeDataByEmpId(ModelMap model,HttpServletRequest request, HttpServletResponse response) {
		logger.info("======getEmployeeDataByEmpId======");
		
		String EmployeeID=request.getParameter("empId");
		
		Employee employee = employeeRepositoryImpl.read(EmployeeID);
		
		logger.info("========Employee========="+new Gson().toJson(employee));
		
		model.addAttribute(new EmployeeBO());
		model.addAttribute("employeeByEmpId", employee);
		//return "apps-add-employee";
		//return new ModelAndView("apps-add-employee");
		return new ModelAndView("apps-employee", "employee", new EmployeeBO());
	}*/
}
