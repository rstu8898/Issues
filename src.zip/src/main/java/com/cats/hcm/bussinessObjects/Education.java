package com.cats.hcm.bussinessObjects;

import java.io.Serializable;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Education implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String employeeId				=	null;
	private String educationQualification	=	null;
	private String nameOfInstitute			=	null;
	
	@DateTimeFormat(pattern="MM-dd-yyyy")
	private Date fromYear					=	null;
	
	private Date toYear						=	null;
	public Date getFromYear() {
		return fromYear;
	}
	public void setFromYear(Date fromYear) {
		this.fromYear = fromYear;
	}
	public Date getToYear() {
		return toYear;
	}
	public void setToYear(Date toYear) {
		this.toYear = toYear;
	}
	private String divisionObtained			=	null;
	
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getEducationQualification() {
		return educationQualification;
	}
	public void setEducationQualification(String educationQualification) {
		this.educationQualification = educationQualification;
	}
	public String getNameOfInstitute() {
		return nameOfInstitute;
	}
	public void setNameOfInstitute(String nameOfInstitute) {
		this.nameOfInstitute = nameOfInstitute;
	}
	public String getDivisionObtained() {
		return divisionObtained;
	}
	public void setDivisionObtained(String divisionObtained) {
		this.divisionObtained = divisionObtained;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
