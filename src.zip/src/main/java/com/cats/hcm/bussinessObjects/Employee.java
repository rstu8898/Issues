package com.cats.hcm.bussinessObjects;

import java.io.Serializable;
import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.format.annotation.DateTimeFormat;

import xyz.morphia.annotations.Entity;
import xyz.morphia.annotations.Id;

@Entity
public class Employee implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	private ObjectId _id;
	
	private String employeeId					=	null;
	private String firstName					=	null;
	private String lastName						=	null;
	private String fatherOrHusbandName			=	null;
	private String motherName					=	null;
	private String contactNumber				=	null;
	private String emailId						=	null;
	private String panCardNumber				=	null;
	private String aadharNumber					=	null;
	private String hobbies						=	null;
	private String interests					=	null;
	private String spouseName					=	null;
	private String spouseAge					=	null;
	private String spouseGender					=	null;
	private String kinName						=	null;
	private String kinAge						=	null;
	private String kinGender					=	null;
	private String emergencyContactName			=	null;
	private String emergencyContactNo			=	null;
	private String emergencyContactRelationship	=	null;
	private String currentDepartment			=	null;
	private String currentDesignation			=	null;
	private String currentJobLocation			=	null;
	private String jobType						=	null;
	private String clientName					=	null;
	private String bloodGroup					=	null;
	private String medicalCase					=	null;
	private String maritalStatusId 				= 	null;
	private String empGender 					= 	null;
	private String techCertificationOne 		= 	null;
	private String techCertificationTwo 		= 	null;
	private byte[] empPhotoFile					=	null;
	private byte[] empPanFile					=	null;
	private byte[] empAadharFile				=	null;
	private byte[] empEducationalFile			=	null;
	private byte[] empExperienceFile			=	null;
	private String createdBy 					= 	null;
	
	private Date createdOn						=	null;
	
	private String updatedBy 					= 	null;
	private Date updatedOn						=	null;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date empDob	=	null; 


	public Date getEmpDob() {
		return empDob;
	}
	public void setEmpDob(Date empDob) {
		this.empDob = empDob;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	public byte[] getEmpPanFile() {
		return empPanFile;
	}
	public void setEmpPanFile(byte[] empPanFile) {
		this.empPanFile = empPanFile;
	}
	public byte[] getEmpAadharFile() {
		return empAadharFile;
	}
	public void setEmpAadharFile(byte[] empAadharFile) {
		this.empAadharFile = empAadharFile;
	}
	public byte[] getEmpEducationalFile() {
		return empEducationalFile;
	}
	public void setEmpEducationalFile(byte[] empEducationalFile) {
		this.empEducationalFile = empEducationalFile;
	}
	
	public ObjectId get_id() {
		return _id;
	}
	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	public String getMaritalStatusId() {
		return maritalStatusId;
	}
	public void setMaritalStatusId(String maritalStatusId) {
		this.maritalStatusId = maritalStatusId;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getMedicalCase() {
		return medicalCase;
	}
	public void setMedicalCase(String medicalCase) {
		this.medicalCase = medicalCase;
	}
	public String getCurrentDepartment() {
		return currentDepartment;
	}
	public void setCurrentDepartment(String currentDepartment) {
		this.currentDepartment = currentDepartment;
	}
	public String getCurrentDesignation() {
		return currentDesignation;
	}
	public void setCurrentDesignation(String currentDesignation) {
		this.currentDesignation = currentDesignation;
	}
	public String getCurrentJobLocation() {
		return currentJobLocation;
	}
	public void setCurrentJobLocation(String currentJobLocation) {
		this.currentJobLocation = currentJobLocation;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public String getClientName() {
		return clientName;
	}
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}




	public String getKinName() {
		return kinName;
	}
	public void setKinName(String kinName) {
		this.kinName = kinName;
	}
	public String getKinAge() {
		return kinAge;
	}
	public void setKinAge(String kinAge) {
		this.kinAge = kinAge;
	}
	public String getKinGender() {
		return kinGender;
	}
	public void setKinGender(String kinGender) {
		this.kinGender = kinGender;
	}
	public String getEmergencyContactName() {
		return emergencyContactName;
	}
	public void setEmergencyContactName(String emergencyContactName) {
		this.emergencyContactName = emergencyContactName;
	}
	public String getEmergencyContactNo() {
		return emergencyContactNo;
	}
	public void setEmergencyContactNo(String emergencyContactNo) {
		this.emergencyContactNo = emergencyContactNo;
	}
	public String getEmergencyContactRelationship() {
		return emergencyContactRelationship;
	}
	public void setEmergencyContactRelationship(String emergencyContactRelationship) {
		this.emergencyContactRelationship = emergencyContactRelationship;
	}
	public String getPanCardNumber() {
		return panCardNumber;
	}
	public void setPanCardNumber(String panCardNumber) {
		this.panCardNumber = panCardNumber;
	}
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public String getHobbies() {
		return hobbies;
	}
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	public String getInterests() {
		return interests;
	}
	public void setInterests(String interests) {
		this.interests = interests;
	}
	public String getSpouseName() {
		return spouseName;
	}
	public void setSpouseName(String spouseName) {
		this.spouseName = spouseName;
	}
	public String getSpouseAge() {
		return spouseAge;
	}
	public void setSpouseAge(String spouseAge) {
		this.spouseAge = spouseAge;
	}
	public String getSpouseGender() {
		return spouseGender;
	}
	public void setSpouseGender(String spouseGender) {
		this.spouseGender = spouseGender;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getFatherOrHusbandName() {
		return fatherOrHusbandName;
	}
	public void setFatherOrHusbandName(String fatherOrHusbandName) {
		this.fatherOrHusbandName = fatherOrHusbandName;
	}
	public String getMotherName() {
		return motherName;
	}
	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getEmpGender() {
		return empGender;
	}
	public void setEmpGender(String empGender) {
		this.empGender = empGender;
	}
	public String getTechCertificationOne() {
		return techCertificationOne;
	}
	public void setTechCertificationOne(String techCertificationOne) {
		this.techCertificationOne = techCertificationOne;
	}
	public String getTechCertificationTwo() {
		return techCertificationTwo;
	}
	public void setTechCertificationTwo(String techCertificationTwo) {
		this.techCertificationTwo = techCertificationTwo;
	}
	public byte[] getEmpPhotoFile() {
		return empPhotoFile;
	}
	public void setEmpPhotoFile(byte[] empPhotoFile) {
		this.empPhotoFile = empPhotoFile;
	}
	public byte[] getEmpExperienceFile() {
		return empExperienceFile;
	}
	public void setEmpExperienceFile(byte[] empExperienceFile) {
		this.empExperienceFile = empExperienceFile;
	}
	
}
