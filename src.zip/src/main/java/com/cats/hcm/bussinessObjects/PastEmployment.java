package com.cats.hcm.bussinessObjects;

import java.io.Serializable;

public class PastEmployment implements Serializable{

	private static final long serialVersionUID = 1L;

	private String employeeId						=	null;
	private String employer							=	null;
	private String employerLocation					=	null;
	private String employerDesignation				=	null;
	private String employerCtcpa					=	null;
	private String employerSupervisorName			=	null;
	private String employerSupervisorMobileNo		=	null;



	
	public String getEmployer() {
		return employer;
	}

	public void setEmployer(String employer) {
		this.employer = employer;
	}

	public String getEmployerLocation() {
		return employerLocation;
	}

	public void setEmployerLocation(String employerLocation) {
		this.employerLocation = employerLocation;
	}

	public String getEmployerDesignation() {
		return employerDesignation;
	}

	public void setEmployerDesignation(String employerDesignation) {
		this.employerDesignation = employerDesignation;
	}

	public String getEmployerCtcpa() {
		return employerCtcpa;
	}

	public void setEmployerCtcpa(String employerCtcpa) {
		this.employerCtcpa = employerCtcpa;
	}

	public String getEmployerSupervisorName() {
		return employerSupervisorName;
	}

	public void setEmployerSupervisorName(String employerSupervisorName) {
		this.employerSupervisorName = employerSupervisorName;
	}

	public String getEmployerSupervisorMobileNo() {
		return employerSupervisorMobileNo;
	}

	public void setEmployerSupervisorMobileNo(String employerSupervisorMobileNo) {
		this.employerSupervisorMobileNo = employerSupervisorMobileNo;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
