package com.cats.hcm.bussinessObjects;

import java.util.List;
import java.util.Set;

public class EmployeeBO extends Employee{

	private static final long serialVersionUID 	= 1L;

	private List<Address> address								=	null;
	
	private List<Education> educationDetails					=	null;
	
	private List<EmployeeChild> childs							=	null;
	
	private List<PastEmployment> pastEmployments				=	null;


	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}
	
	public List<PastEmployment> getPastEmployments() {
		return pastEmployments;
	}

	public void setPastEmployments(List<PastEmployment> pastEmployments) {
		this.pastEmployments = pastEmployments;
	}

	public List<Education> getEducationDetails() {
		return educationDetails;
	}

	public void setEducationDetails(List<Education> educationDetails) {
		this.educationDetails = educationDetails;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<EmployeeChild> getChilds() {
		return childs;
	}

	public void setChilds(List<EmployeeChild> childs) {
		this.childs = childs;
	}
}
