package com.cats.hcm.bussinessObjects;

import java.io.Serializable;
import java.util.Date;

public class EmployeeChild implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String employeeId				=	null;
	private String childName				=	null;
	private String childAge					=	null;
	private String childGender				=	null;
	
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	public String getChildName() {
		return childName;
	}
	public void setChildName(String childName) {
		this.childName = childName;
	}
	public String getChildAge() {
		return childAge;
	}
	public void setChildAge(String childAge) {
		this.childAge = childAge;
	}
	public String getChildGender() {
		return childGender;
	}
	public void setChildGender(String childGender) {
		this.childGender = childGender;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
