package com.cats.hcm.bussinessObjects;

import java.io.Serializable;

public class MaritalStatus implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer maritalStatusId 	= 	null;
	private String maritalStatusName	=	null;
	
	
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Integer getMaritalStatusId() {
		return maritalStatusId;
	}

	public void setMaritalStatusId(Integer maritalStatusId) {
		this.maritalStatusId = maritalStatusId;
	}

	public String getMaritalStatusName() {
		return maritalStatusName;
	}

	public void setMaritalStatusName(String maritalStatusName) {
		this.maritalStatusName = maritalStatusName;
	}
}
