package com.cats.hcm.bussinessObjects;

import java.io.Serializable;

public class Employment implements Serializable{

	private static final long serialVersionUID = 1L;

	private String employeeId		=	null;
	private String companyName		=	null;
	
	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
